//css
import 'bootstrap/dist/css/bootstrap.css';
// import { Button } from "ui";
import Landing from "./landing";

export default function Web() {
  return (
    <div>
      <Landing />
    </div>
  );
}
