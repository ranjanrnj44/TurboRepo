import * as React from "react";
export const Buttons = () => {
  return <button style={{backgroundColor: "green",
    padding: "0.8rem",
    border: "none",
    borderRadius: "0.5rem",
    color: "white",
    fontWeight: "bold", cursor:"pointer"}} onClick={() => console.log("event triggred!")} >share_dBtn</button>;
};
